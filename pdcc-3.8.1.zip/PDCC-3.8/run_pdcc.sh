﻿echo
dirnm=`dirname $0`
cd $dirnm
java -Xmx768m -jar ./run_pdcc.jar

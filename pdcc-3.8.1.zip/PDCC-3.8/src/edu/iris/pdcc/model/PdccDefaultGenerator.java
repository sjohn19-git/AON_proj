package edu.iris.pdcc.model;

import edu.iris.Fissures.seed.exception.*;
import edu.iris.Fissures.seed.container.*;

/**
 * A factory class for returning generic representations for PdccObject types, filling the fields with
 * 'stuffing', nonsense values that are nonetheless syntactically correct.  Used for creating New, Blank PdccObjects
 * to be filled in by the user.
 * @author Robert Casey, IRIS DMC
 * @version 2005
 */
public class PdccDefaultGenerator {
    
    /**
     * return a delimited string consisting of appropriate field values for ther indicated object type.
     * @param objectType the object type to create a boilerplate for
     * @return a String representation of the new object
     * @throws SeedException
     */
    public static String getDefaults(int objectType) throws SeedException {
        StringBuffer defaultStringBuf = new StringBuffer();
        try {
            if (objectType > 0) {
                // this is a blockette object, get the number of fields
                int numFields = BlocketteFactory.getNumFields(objectType, defaultSEEDVersion);
                for (int i = 0; i < numFields; i++) {  // for each field
                    int fieldNum = i + 1;   // blockettes start field count at 1
                    String fieldVal = null;
                    if (fieldNum == 1) {
                        // insert the blockette type as the first field value
                        defaultStringBuf.append(Integer.toString(objectType));
                        continue;  // go to the next field
                    } else {
                        // see if there is a special field value
                        fieldVal = getSpecialDefault(objectType,fieldNum);
                        // otherwise, put in a generic default appropriate to the field type
                        if (fieldVal == null) {
                            
                            // get the mask/flags for this field
                            String fldMask = BlocketteFactory.getFieldMask(objectType,fieldNum);
                            //
                            if (fldMask.charAt(0) == '"') {         // number format string
                                // assign default value of zero
                                fieldVal = "0";
                            } else if (fldMask.charAt(0) == '[') {  // character flags
                                char c;
                                boolean testUpper = false;
                                boolean testLower = false;
                                boolean testDigit = false;
                                boolean testPunct = false;
                                boolean testUnder = false;
                                
                                // proceed through the mask characters to get a list of acceptable
                                // character types for this field
                                for (int j = 1; j < fldMask.length() && (c = fldMask.charAt(j)) != ']'; j++) {
                                    switch (c) {
                                    case 'U':
                                        testUpper = true;
                                        break;
                                    case 'L':
                                        testLower = true;
                                        break;
                                    case 'N':
                                        testDigit = true;
                                        break;
                                    case 'P':
                                        testPunct = true;
                                        break;
                                    case '_':
                                        testUnder = true;
                                        break;
                                    }
                                }
                                
                                // proceed with checks from most desirable substitution to least
                                // desirable.
                                if (testUpper) fieldVal = "X";
                                else if (testLower) fieldVal = "x";
                                else if (testDigit) fieldVal = "0";
                                else if (testPunct) fieldVal = "?";
                                else if (testUnder) fieldVal = "_";
                                else fieldVal = blank;  // fallback to blank
                            }  else {  // other mask patterns are ignored, go with blank
                                fieldVal = blank;
                            }
                        }
                    }
                    // take the determined fieldVal and add it to our delimited list
                    defaultStringBuf.append(delimiter);
                    defaultStringBuf.append(fieldVal);
                }
            }
        } catch (Exception e) {
            throw new SeedException(
                    "Exception encountered while getting default value for field in object of object type " +
                    objectType + ": " + e);
        }
        // return the resultant concatenated string
        //System.err.println("DEBUG: default string: " + defaultStringBuf);
        return defaultStringBuf.toString();
    }


    // return a default entry needed for the indicated field (of the indicated blockette type)
    // to be a viable SEED blockette entry.  If the field can safely be null, the returned
    // result will be null.
    public static String getSpecialDefault(int type, int field) {
        String defaultVal = null;
        
        switch (type) {  //  check object type
        case 5:  // Field Volume Identifier Blockette
            switch (field) {
            case 3:  // version of format
                defaultVal = Float.toString(defaultSEEDVersion);
                break;
            case 5:  // beginning of volume
                defaultVal = beginTime;
                break;
            }
            break;
        case 8:  // Telemetry Volume Identifier Blockette
            switch (field) {
            case 3:  // version of format
                defaultVal = Float.toString(defaultSEEDVersion);
                break;
            case 5:  // station identifier
                defaultVal = "XXXXX";
                break;
            case 6:  // location identifier
                defaultVal = "  ";
                break;
            case 7:  // channel identifier
                defaultVal = "XXX";
                break;
            case 8:  // beginning of volume
            case 10: // station information effective date
            case 11: // channel information effective date
                defaultVal = beginTime;
                break;
            case 9:  // end of volume
                defaultVal = endTime;
                break;
            case 12: // network code
                defaultVal = "XX";
                break;
            }
            break;
        case 10:  // Volume Identifier Blockette
            switch (field) {
            case 3:  // version of format
                defaultVal = Float.toString(defaultSEEDVersion);
                break;
            case 5:  // beginning time
                defaultVal = beginTime;
                break;
            case 6:  // end time
                defaultVal = endTime;
                break;
            case 7:  // volume time
                defaultVal = beginTime;
                break;
            case 8:  // originating organization
                defaultVal = "PDCC User";
                break;
            case 9:  // label
                defaultVal = "PDCC SEED Volume";
                break;
            }
            break;
        case 50:   // Station Blockette
            switch (field) {
            case 3:  // station identifier
                defaultVal = "XXXXX";
                break;
            case 11: // 32 bit word order
                defaultVal = "3210";
                break;
            case 12:  // 16 bit word order
                defaultVal = "10";
                break;
            case 13:  // start eff time
                defaultVal = beginTime;
                break;
            case 15:  // update flag
                defaultVal = "N";
                break;
            case 16:  // network code
                defaultVal = "XX";
                break;
            }
            break;
        case 51:  // Station Comment Blockette
            switch (field) {
            case 3:  // beginning eff time
                defaultVal = beginTime;
                break;
            case 4:  // end eff time
                defaultVal = endTime;
                break;
            }
            break;
        case 52:  // Channel Blockette
            switch (field) {
            case 3:  // location identifier
                defaultVal = "  ";
                break;
            case 4:  // channel identifier
                defaultVal = "XXX";
                break;
            case 17: // record length exponent
                defaultVal = "12";
                break;
            case 21:  // channel flags
                defaultVal = "CG";
                break;
            case 22:  // start date
                defaultVal = beginTime;
                break;
            case 24:  // update flag
                defaultVal = "N";
                break;
            }
            break;
        case 53:  // Response PZ Blockette
            switch (field) {
            case 3:  // transfer function type
                defaultVal = "A";
                break;
            }
            break;
        case 54:  // Response Coeff Blockette
            switch (field) {
            case 3:  // transfer function type
                defaultVal = "A";
                break;
            }
            break;
        case 59:  // Channel Comment Blockette
            switch (field) {
            case 3:
                defaultVal = beginTime;
                break;
            case 4:  // end eff time
                defaultVal = endTime;
                break;
            }
            break;
        case 61:  // FIR Response Blockette
            switch (field) {
            case 5:
                defaultVal = "A";
                break;
            }
            break;
            
        }   // END check object type
        
        return defaultVal;
    }
    
    public static final String blank = "^";
    public static final String delimiter = "|";
    public static final String beginTime = "1970,001,00:00:00.0000";
    public static final String endTime = "2500,365,23:59:59.9999";
    private static float defaultSEEDVersion = 0.0F;
    static {
        defaultSEEDVersion = Blockette.getDefaultVersion();
    }


}
package edu.iris.pdcc.model;

import edu.iris.Fissures.seed.container.*;


/**
 * This class provides a mapping between blockettes and the field values they would display
 * as a short-hand label representation for things like TreeCells.
 * @author Robert Casey, IRIS DMC
 * @version November 2011
 *
 */
public class PdccBlocketteLabelMap {

    /**
     * Return a String that represents a label for either the type
     * of blockette this is, or the identifying contents of the blockette...or both.
     * Return a default String if there is no specific mapping.
     */
    public static String getLabel(Blockette blk) {
        int blkType = blk.getType();
        if (blkType < 1) {
            return blk.toString();
        }
        StringBuffer outputStrBuf = new StringBuffer();
        // return a title string, or a default object name
        String mainTitle = arrayMainTitle[findObjTypeIndex(blkType)];
        if (mainTitle != null) {
            outputStrBuf.append(mainTitle);
        } else {
            try {
                outputStrBuf.append(blk.getName());
            } catch (Exception e) {
            	outputStrBuf.append("type " + blkType);
            }
        }
        // return field contents or just a unique ID number
        int[] fieldNums = arrayFieldLabel[findObjTypeIndex(blkType)];
        if (fieldNums != null) {
            for (int i = 0; i < fieldNums.length; i++) {
                outputStrBuf.append(String.valueOf(delimiter));  // delimited string
                outputStrBuf.append(blk.toString(fieldNums[i]));  // next field value
            }
            // append the type number in parens
            outputStrBuf.append("(type ");
            outputStrBuf.append(blkType);
            outputStrBuf.append(")");
        }
        return outputStrBuf.toString();
    }
    
    /**
     * Return a String that represents a label for the blockette indicated by
     * the tag ID provided.  Does not access the blockette directly.
     * Return a default String if there is no specific mapping.
     */
    public static String getLabel(String tagID) {
        if (tagID == null || tagID.length() == 0) return "empty";
        String[] tagComponents = tagID.split("\\.");
        if (tagComponents.length == 0) return "tagID";
        int blkType = new Integer(tagComponents[0]);
        if (blkType < 1) {
            return "tagID";
        }
        StringBuffer outputStrBuf = new StringBuffer();
        // return a title string, or a default object name
        String mainTitle = getMainTitle(blkType);
        if (mainTitle != null) {
            if (blkType == 58 && mainTitle.equals("Gain")) {
                if (tagComponents.length > 6 && tagComponents[6].equals("0000")) {
                    mainTitle = "Sensitivity";  // change the label
                }
            }
            outputStrBuf.append(mainTitle);
        }
        // return field contents or just a unique ID number
        String tagLabels = getTagLabels(blkType,tagComponents);
        if (tagLabels != null) {
            outputStrBuf.append(" ");
            outputStrBuf.append(tagLabels);
        }   
//            // append the type number in parens
//            outputStrBuf.append("(type ");
//            outputStrBuf.append(blkType);
//            outputStrBuf.append(")");     
        return outputStrBuf.toString();
    }

    /**
     * return an integer array of field numbers in the PdccObject that are to have
     * their values pieced together in order for a displayed label of the
     * PdccObject.  Return null if there are no field numbers to provide.
     */
    public static int[] getFieldLabels(int blkType) {
        switch (blkType) {
        case 5:
        case 8:
        case 10:
        case 11:
        case 12:
            return null;
        case 30:
            return new int[] {1,4,3};
        case 31:
            return new int[] {1,3,5};
        case 32:
            return new int[] {1,3,4};
        case 33:
            return new int[] {1,3,4};
        case 34:
            return new int[] {1,3,4,5};
        case 35:
            return new int[] {1,3,4,5};
        case 41:
            return new int[] {1,3,4,8};
        case 42:
            return new int[] {1,3,4,15};
        case 43:
            return new int[] {1,3,4,10,15};
        case 44:
            return new int[] {1,3,4,8,11};
        case 45:
            return new int[] {1,3,4,7};
        case 46:
            return new int[] {1,3,4,7};
        case 47:
            return new int[] {1,3,4,6};
        case 48:
            return new int[] {1,3,4,5};
        case 50:
            return new int[] {3,16,13};
        case 51:
            return new int[] {1,3};
        case 52:
            return new int[] {4,3,22};
        case 53:
            return new int[] {4,1,9,14};
        case 54:
            return new int[] {4,1,7,10};
        case 55:
            return new int[] {3,1,6};
        case 56:
            return new int[] {3,1,6};
        case 57:
            return new int[] {3,1,5};
        case 58:
            return new int[] {3,1,6};
        case 59:
            return new int[] {1,3};
        case 60:
            return new int[] {4,1,3};
        case 61:
            return new int[] {3,1,8};
        case 62:
        	return new int[] {4,1,14};
        case 999:  //FSDH
            return new int[] {4,7,6,8};
        case 100:
        case 200:
        case 201:
        case 300:
        case 310:
        case 320:
        case 390:
        case 395:
        case 400:
        case 405:
        case 500:
        case 1000:
        case 1001:
        default:
            return null;
        }
    }

    
    /**
     * return an integer array that represents the fields
     * containing the referenced abbreviation value(s).
     * Only applies to certain abbreviation blockettes.
     */
    public static int[] getAbbreviationFields(int blkType) {
        switch (blkType) {
        case 30:
            return new int[] {3};
        case 31:
            return new int[] {5};
        case 32:
            return new int[] {4};
        case 33:
            return new int[] {4};
        case 34:
            return new int[] {4,5};
        case 35:
            return new int[] {5,6,7};
        case 41:
        case 42:
        case 43:
        case 44:
        case 45:
        case 46:
        case 47:
        case 48:
            return new int[] {4};
        default:
            return null;
        }
    }



    // private methods
    //

    /**
     * Return a string that represents a primary title for the provided object type.
     * Return null if there is no string to return.
     */
    private static String getMainTitle(int blkType) {
        switch (blkType) {
        case 5:
        case 8:
        case 10:
        case 11:
        case 12:
            return null;
        case 30:
            return "Data_Format";
        case 31:
            return "Comment";
        case 32:
            return "Cited_Source";
        case 33:
            return "Abbreviation";
        case 34:
            return "Unit";
        case 35:
            return "Beam_Config";
        case 42:
            return "Polynomial";
        case 43:
        case 53:
            return "Poles_Zeros";
        case 41:
        case 44:
        case 54:
        case 61:
            return "FIR";
        case 45:
        case 55:
            return "FAP";
        case 46:
        case 56:
            return "Corners";
        case 47:
        case 57:
            return "Decimation";
        case 48:
        case 58:
            return "Gain";
        case 50:
            return "Station";
        case 51:
            return "Station_Comment";
        case 52:
            return "Channel";
        case 59:
            return "Channel_Comment";
        case 60:
            return "Compound_Resp";
        case 62:
            return "Nonlinear";
        case 999:  //FSDH
        case 100:
        case 200:
        case 201:
        case 300:
        case 310:
        case 320:
        case 390:
        case 395:
        case 400:
        case 405:
        case 500:
        case 1000:
        case 1001:
            return "Waveform";
        default:
            return null;     // return null on exception
        }
    }
    
    
    /**
     * Return a string that provides a meaningful identifier from the tag for the provided type
     */
    private static String getTagLabels(int blkType, String[] tagFields) {
        switch (blkType) {
        // 030.ABBREV.0001.String.Hash
        case 30:
        case 31:
        case 32:
        case 33:
        case 34:
        case 35:
        case 41:
        case 42:
        case 43:
        case 44:
        case 45:
        case 46:
        case 47:
        case 48:
            if(tagFields.length > 3) return tagFields[2] + " " + tagFields[3];
            else return null;
        // 053.AK.MCK.a.--BHE.2000_100_00_00_00.0001
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:
        case 58:
        case 61:
        case 62:
            if (tagFields.length > 6) return "Stage " + tagFields[6];
            else return null;
        case 50:
            if (tagFields.length > 5) return tagFields[1] + "." + tagFields[2] + ", " + tagFields[5];
            else return null;
        case 51:
        case 59:
            if (tagFields.length > 5) return tagFields[5];
            else return null;
        case 52:
            if (tagFields.length > 5) return tagFields[4] + ", " + tagFields[5];
            else return null;
        default:
            return null;     // return null on exception
        }
    }

    /**
     * Return an integer representing the index number of the objectTypes array
     * where the provided object type can be found.  This index number also
     * corresponds to the label and title arrays that are statically generated, so
     * this function is used to map to those arrays.
     * Return -1 if not found.
     */
    private static int findObjTypeIndex(int objType) {
        for (int i = 0; i < objectTypes.length; i++) {
            if (objType == objectTypes[i]) return i;
        }
        return -1;
    }


    // static fields for lookup optimization
    private static final int[] objectTypes = {
        5,8,10,11,12,30,31,32,33,34,35,41,42,43,44,45,46,47,48,
        50,51,52,53,54,55,56,57,58,59,60,61,62,
        999,100,200,201,300,310,320,390,395,400,405,500,1000,1001
    };
    private static final int numberOfObjectTypes = objectTypes.length;
    private static int[][] arrayFieldLabel = new int[numberOfObjectTypes][];  // field for label
    private static String[] arrayMainTitle = new String[numberOfObjectTypes]; // main title string

    // static intialization block -- runs when class first loaded
    static {
        try {
            for (int i = 0; i < numberOfObjectTypes; i++) {
                int objType = objectTypes[i];
                arrayFieldLabel[i] = getFieldLabels(objType);
                arrayMainTitle[i] = getMainTitle(objType);
            }
        } catch (Exception e) {
            // report and exit upon encountering an exception
            System.out.println("Caught exception: " + e);
            e.printStackTrace();
            System.exit (1);
        }
    }
    private static final char delimiter = ' ';  // label and title string delimiter


}

package edu.iris.pdcc.tools;

import java.util.concurrent.*;
import edu.iris.nrl.CallBackSourceParam;
//import edu.iris.nrl.gui.NrlConfigDialog;
import edu.iris.nrl.gui.NrlToolGui;
import edu.iris.nrl.gui.BasicNrlToolLauncher;
import edu.iris.Fissures.seed.container.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.*;
import javax.swing.*;
import edu.iris.pdcc.model.*;

/**
 *
 * @author Robert Casey, IRIS DMC<br>
 *          Kevin Frechette, ISTI
 * @version July 2010 -- updated for NRL Tool v0.17
 */
public class NRLToolLauncher extends BasicNrlToolLauncher implements CallBackSourceParam {

    // call up an instance of the NRL Tool and show the tool
    private NRLToolLauncher(JFrame frame, Executor ex) {
      super(frame, ex);
      setCallBackObj(this);
    }

    // call up an instance of the NRL Tool and show the tool
    // assign an observer to the launcher to watch for completion
    private NRLToolLauncher(Observer o, JFrame frame, Executor ex) {
      super(frame, ex);
      setCallBackObj(this);
      assignObserver(o);
    }

    // return a single instance of this launcher
    public static NRLToolLauncher getInstance() {
        if (launcher == null) {
          launcher = new NRLToolLauncher(null,getNewExecutor());
        //} else {
            //final NrlToolGui nrlToolGui = launcher.getNrlToolGui();
            //if (nrlToolGui.isFinished()) nrlToolGui.reset(false);
        }
        return launcher;
    }

    // return a single instance of this launcher attached to the indicated parent frame
    public static NRLToolLauncher getInstance(JFrame frame) {
        if (launcher == null) {
            launcher = new NRLToolLauncher(frame,getNewExecutor());
        //} else {
            //final NrlToolGui nrlToolGui = launcher.getNrlToolGui();
            //if (nrlToolGui.isFinished()) nrlToolGui.reset(false);
        }
        return launcher;
    }

    // return a single instance of this launcher attached to the indicated parent frame
    // assign observer to watch for completion of the tool
    public static NRLToolLauncher getInstance(Observer o, JFrame frame) {
        if (launcher == null) {
            launcher = new NRLToolLauncher(o,frame,getNewExecutor());
        //} else {
            //final NrlToolGui nrlToolGui = launcher.getNrlToolGui();
            //if (nrlToolGui.isFinished()) nrlToolGui.reset(false);
        }
        return launcher;
    }

    // return a single NEW instance of this launcher attached to the indicated parent frame
    // assign observer to watch for completion of the tool
    public static NRLToolLauncher getNewInstance(Observer o, JFrame frame) {
        launcher = new NRLToolLauncher(o,frame,getNewExecutor());
        return launcher;
    }

    // this tells the tool launcher instance to send an update() signal to the assigned
    // observer as tasks are completed.  Generally the obeserver is the caller to
    // this tool launcher.
    public void assignObserver(Observer o) {
        currentObserver = o;
    }

    // this will allow us to assign a container that can be filled with data in the
    // callBackMethod when the launched tool has finished successfully
    // DEPENDS ON assignObserver() being called first
    public void assignContainer(SeedVolumeMMAPContainer container) {
        //System.err.println("DEBUG: NRL tool launcher assigned container: " + container);
        currentContainer = container;
        // assign observer if present
        if (currentObserver != null) currentContainer.registerObserver(currentObserver);
    }

    // this will affix the context (blockette) this tool is acting on, regardless of what the user
    // selects outside of this tool before finishing.
    // DEPENDS ON assignContainer() being called first
    public void assignContext(SeedObjectTag context) {
        currentContext = context;
        // assign context to container if container is present
        if (currentContainer != null) currentContainer.setContext(currentContext);
    }


    // return the assigned instance of the NRL Tool GUI
    public NrlToolGui getGuiInstance() {
        return launcher.getNrlToolGui();  // this value could be null when launcher is first started
    }

    public void showNrlToolGUI() {  // bring up the NRL Tool Dialog
//        System.err.println("DEBUG: show NRL Tool GUI called...");
        launcher.getExecutor().execute(launcher);
        nrlToolGui = launcher.getNrlToolGui();
    }

    /**
    * Method called by the implementing class (NrlToolGui)
    * @param source the source of the call-back.
    */
    public void callBackMethod(Object source) {
        // using reflection to determine how to handle callback
        if (source instanceof NrlToolGui) {
                  //final NrlToolGui nrlToolGui = (NrlToolGui) source;
                  nrlToolGui = (NrlToolGui) source;
                  if (nrlToolGui.isFinished()) {
                            //
                            // feed the input stream to the container
                            //
                            if (currentContainer == null) {
                                System.err.println("WARNING: no container selected for NRL output");
                                System.err.println("Selected sensor: " + nrlToolGui.getRespInfo("Sensor").getDescription()  );
                                System.err.println("Selected datalogger: " + nrlToolGui.getRespInfo("Datalogger").getDescription()  );
                                nrlToolGui.getBlocketteStringOutput();  // send the contents to stdout
                            } else {
                                try {
                                    // set the container context (where we will be inserting responses)
                                    // context == target channel
                                    if (currentContext != null) {
                                        currentContainer.setContext(currentContext);  // an assigned context is the safest mode
                                    }
                                    // reflect back the current container context
                                    SeedObjectTag channelContext = currentContainer.getContext();

                                    // DEBUG:
                                    //System.err.println("DEBUG: NRL Tool - channelContext = " + channelContext);

                                    // delete current child responses at the context location
                                    for (SeedObjectTag respTag : currentContainer.getChildTags(channelContext)) {
                                        //System.err.println("DEBUG: NRLToolLauncher: delete resp tag: " + respTag);
                                        currentContainer.deleteData(respTag);  // delete this response element
                                    }
                                    //
                                    // create a new b33 entry that contains the response description for this NRL selection
                                    String sensorDesc = nrlToolGui.getRespInfo("Sensor").getDescription();
                                    String loggerDesc = nrlToolGui.getRespInfo("Datalogger").getDescription();
                                    String b33str = PdccDefaultGenerator.getDefaults(33);
                                    Blockette blk33 = BlocketteFactory.createBlockette(b33str);
                                    blk33.setFieldVal(3, "001");  // lookup ID - this will be reindexed by the container
                                    blk33.setFieldVal(4, sensorDesc + "-" + loggerDesc);  // modify field 4
                                    // append entry to the container and modify lookup index of channel -- synchronous
                                    //System.err.println("DEBUG: addAbbrevToContext = " + blk33.toString());
                                    currentContainer.addAbbrevToContext(6, blk33.toString());
                                    //
                                    // stream in the new child responses at the context location from the NRL selections
                                    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                                    nrlToolGui.getBlocketteStringOutput(outStream);  // give the GUI something to fill
                                    ByteArrayInputStream inStream = new ByteArrayInputStream(outStream.toByteArray());  // put it to an input stream
                                    currentContainer.importChildren(inStream);  // observer will be notified here - twice (abbrev, station)
                                    outStream.close();  // close the output stream
                                //
                                } catch (Exception e) {
                                    System.err.println("ERROR: NRLToolLauncher: Exception thrown: " + e);
                                    e.printStackTrace();
                                }
                            }
                    }
              
        }
  }


  public boolean isRunning() {
      return (nrlToolGui != null && !nrlToolGui.isFinished() && !nrlToolGui.isTerminated());
  }

  
//  @Override
//  public void run() {
//      System.err.println("DEBUG: run thread called...");
//      super.run();
//  }


  private static Executor getNewExecutor() {
      //return Executors.newSingleThreadExecutor();
      return Executors.newFixedThreadPool(10);
  }


  /* main method for the purposes of testing the launcher */
  public static void main(String[] args) {
      System.err.println("DEBUG: run first time through...");
      NRLToolLauncher myLauncher = NRLToolLauncher.getInstance();
      myLauncher.showNrlToolGUI();

      while (myLauncher.isRunning());
      
      System.err.println("DEBUG: run second time through...");
      myLauncher = NRLToolLauncher.getInstance();  // redundant, but test singleton anyway
      myLauncher.showNrlToolGUI();

      while (myLauncher.isRunning());
      System.err.println("DEBUG: we are done.");
  }


  // keep a single instance of the Launcher
  private static NRLToolLauncher launcher = null;
  /* the current container that the NRL will feed data into */
  private SeedVolumeMMAPContainer currentContainer = null;
  /* the current container observer */
  private Observer currentObserver = null;
  /* the current context object that we are acting on (e.g. a Channel) */
  private SeedObjectTag currentContext = null;

  private NrlToolGui nrlToolGui = null;

}

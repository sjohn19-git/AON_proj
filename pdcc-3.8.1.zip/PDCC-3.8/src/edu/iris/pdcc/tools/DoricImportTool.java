package edu.iris.pdcc.tools;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
//import java.util.regex.*;
import javax.swing.table.*;
import javax.swing.*;
import javax.swing.border.*;
import edu.iris.Fissures.seed.container.*;
import edu.iris.pdcc.model.*;
import javax.security.auth.callback.*;

/**
 * Doric - Do Response Import Columns
 * An import tool that fills out a selected response blockette with
 * coefficients drawn from a columnar text file.
 * @author Chris Laughbon, IRIS DMC<br>
 *          Robert Casey, IRIS DMC (adapted to PDCC)
 * @version March, 2009
 */
public class DoricImportTool {

    /**
     * Constructor to create the import tool.  You have to pass it a blockette for it to modify.
     * @param blk the blockette to add coefficients into
     * @param s the field number that the coefficient group starts at
     * @param e the end field number of the coefficient group
     * @param handler an assigned handler of callback information for channeling the edited blockette
     * @throws edu.iris.Fissures.seed.exception.SeedException
     */
    public DoricImportTool(Blockette blk, int s, int e, CallbackHandler handler) throws edu.iris.Fissures.seed.exception.SeedException {
        String[] colNames;
        int num_rows;
        int num_cols;
        int row, col;
        int i;
        Vector rowV;
        JPanel btn_panel;
        JPanel head_panel;
        DefaultTableModel dtm;
        Font defaultFont = new Font("Dialog", Font.BOLD, 14);
        Border blackLineBorder = BorderFactory.createLineBorder(Color.black);
        //Box mainBox;
        GridBagConstraints c = new GridBagConstraints();
        Float[][] table_data;

        this.blk = blk;

        haveEdits = false;

        startField = s;

        blocketteHandler = handler;

//System.err.println("DEBUG: type: " + blk.getType() + ", start: " + s + ", end: " + e);

        JButton appendBtn = new JButton("Append");
        JButton insertBtn = new JButton("Insert (overwrite)");
        JButton deleteBtn = new JButton("Delete row(s)");
        JButton applyBtn = new JButton("Apply");
        JButton closeBtn = new JButton("Close");

        appendBtn.setFont(defaultFont);
        insertBtn.setFont(defaultFont);
        applyBtn.setFont(defaultFont);
        closeBtn.setFont(defaultFont);
        deleteBtn.setFont(defaultFont);

        btn_panel = new JPanel();
        btn_panel.setBorder(BorderFactory.createTitledBorder(
                blackLineBorder, " Import from file ",
                TitledBorder.CENTER,
                TitledBorder.TOP));

        // Display a description of the tool
        JLabel app_name = new JLabel("Columnar text file import tool.");
        app_name.setFont(defaultFont);
        JPanel appName_panel = new JPanel();
        appName_panel.add(app_name);  // display app description

        // Display the kind of blockette we are working on
        JLabel blk_name = new JLabel("Type " + blk.getType() + ": " + blk.getName()); // displays the name of the blockette type
        blk_name.setFont(defaultFont);
        head_panel = new JPanel();
        head_panel.setBorder(BorderFactory.createLineBorder(Color.black, 5));  // add a border
        head_panel.add(blk_name);  // display blockette name

        // Set up the main frame
        main_frame = new JFrame("Doric - v" + version);  // print title and version

        main_panel = new JPanel();
        main_panel.setLayout(new GridBagLayout());

        main_frame.getContentPane().add(main_panel);

        main_frame.setSize(width, height);

        main_frame.setVisible(true);

        c.anchor = GridBagConstraints.WEST;

        c.gridy = 0;
        c.gridx = 0;
        c.weightx = 100;
        c.weighty = 100;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.insets.left = 2; //5;
        c.insets.right = 2; //5;
        c.insets.top = 2; //5;
        c.insets.bottom = 2; //5;

        colNames = new String[(e - s) + 1];

        for (i = 0; i < colNames.length; i++) {
            colNames[i] = blk.getFieldName(s + i);
        }

        num_rows = Integer.parseInt((blk.getFieldVal(blk.getFieldRepeat(s)).toString()));

        num_cols = colNames.length;

        table_data = new Float[num_rows][num_cols];

        for (row = 0; row < num_rows; row++) {
            rowV = blk.getFieldGrp(s, row);

            for (col = 0; col < rowV.size(); col++) {
                table_data[row][col] = new Float((rowV.get(col)).toString());
            }

        }

        dtm = new DefaultTableModel(table_data, colNames);

        table = new JTable(dtm);

        table.setFont(defaultFont);

        sp = new JScrollPane(table);

        sp.setPreferredSize(new Dimension(width - 100, height - 250));

        sp.setBorder(BorderFactory.createLoweredBevelBorder());

        // draw app descriptor at top center
        c.anchor = GridBagConstraints.NORTH;//GridBagConstraints.CENTER;
        c.gridwidth = 5;
        c.gridy = 0;
        c.weighty = 5;  // compress these more than the coefficient table
        main_panel.add(appName_panel, c);

        // draw blockette description below that
        c.gridy = 1;
        main_panel.add(head_panel, c);

        // draw the coefficient table display below that
        c.gridheight = 15;
        c.gridy = 2; //1;
        c.weighty = 50;  // this is the dominant weighted grid
        main_panel.add(sp, c);

        // draw the button panels below table display
        c.anchor = GridBagConstraints.SOUTH;
        btn_panel.add(appendBtn);
        btn_panel.add(insertBtn);
        //c.gridy = 3; //16;
        c.gridwidth = 2;
        main_panel.add(btn_panel, c);

        c.gridx += 2;
        c.gridwidth = 1;
        main_panel.add(deleteBtn, c);

        c.gridx++;
        main_panel.add(applyBtn, c);

        c.gridx++;
        main_panel.add(closeBtn, c);

        main_frame.addComponentListener(new ComponentAdapter() {

            public void componentResized(ComponentEvent e) {
                sp.setPreferredSize(new java.awt.Dimension(e.getComponent().getSize().width - 100,
                        e.getComponent().getSize().height - 250));

            }
        });

        insertBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                fromFile(false);	// true means append, false, insert
            }
        });


        appendBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                fromFile(true);	// true means append, false, insert
            }
        });


        deleteBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                deleteRow();
            }
        });

        closeBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                if (haveEdits) {
                    int ret = JOptionPane.showConfirmDialog(main_panel,
                            "You have unsaved edits. Ok to leave?",
                            "Warning",
                            JOptionPane.YES_NO_OPTION);

                    // ret == 0 ? means confirm, 1 means no

                    if (ret == 1) {
                        return;
                    }

                }

                main_frame.dispose();

            }
        });

        applyBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                apply();
            }
        });

        tk = main_frame.getToolkit();

        main_frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent we) {
                if (haveEdits) {
                    int ret = JOptionPane.showConfirmDialog(main_panel,
                            "You have unsaved edits. Ok to leave?",
                            "Warning",
                            JOptionPane.YES_NO_OPTION);

                    // ret == 0 ? means confirm, 1 means no

                    if (ret == 1) {
                        return;
                    }

                }

                main_frame.dispose();
            }
        });

        //main_frame.show();
        main_frame.setVisible(true);

    }

    void apply() {
        Vector rowV = new Vector();

        int now_row, now_col, num_cols, col, row, num_rows;

        if (!haveEdits) {
            JOptionPane.showMessageDialog(main_panel, "There are no edits to apply (save)");

            return;

        }

        DefaultTableModel dtm = (DefaultTableModel) table.getModel();

        try {
            num_rows = Integer.parseInt((blk.getFieldVal(blk.getFieldRepeat(startField)).toString()));

            for (row = 0; row < num_rows; row++) {
                blk.deleteFieldGrp(startField, row);
            }

            num_rows = table.getRowCount();
            num_cols = table.getColumnCount();

            for (now_row = 0; now_row < num_rows; now_row++) {
                for (now_col = 0; now_col < num_cols; now_col++) {
                    rowV.add(table.getValueAt(now_row, now_col));
                }

                blk.addFieldGrp(startField, rowV);

                rowV.clear();


            }

            // if we have a registered handler, then send back the blockette string to the handler
            if (blocketteHandler != null) {
                TextOutputCallback[] callBack = {null};  // array of length 1
                callBack[0] = new TextOutputCallback(TextOutputCallback.INFORMATION, blk.toString());
                blocketteHandler.handle(callBack);
            }

        } catch (edu.iris.Fissures.seed.exception.SeedException ex) {
            System.err.println("Unable to apply changes. Error:" + ex.getMessage());
        } catch (IOException e) {
            System.err.println("ERROR: IOexception in tool callback: " + e);
        } catch (javax.security.auth.callback.UnsupportedCallbackException e) {
            System.err.println("ERROR: UnsupportedCallbackException in tool callback: " + e);
        }


        main_frame.dispose();

    }

    void deleteRow() {
        int[] rows;
        int r;

        if (table.getSelectedRowCount() == 0) {
            tk.beep();
            return;

        }

        DefaultTableModel dtm = (DefaultTableModel) table.getModel();

        rows = table.getSelectedRows();

        // make sure they are ordered
        Arrays.sort(rows);

        // work backwords to we don't have to worry about shifting indexes
        for (r = rows.length - 1; r >= 0; r--) {
            dtm.removeRow(rows[r]);
        }

        haveEdits = true;

    }

    void fromFile(boolean append) {

        DefaultTableModel dtm;

        dtm = (DefaultTableModel) table.getModel();

        BufferedReader br;

        String flds[];

        String inStr;

        int returnVal;

        int row, col, num_rows;

        int fromRow;

        Vector fromFile;

        fromFile = new Vector();

        //String pattern = Pattern.compile("\\s+").pattern();

        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));

        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        chooser.setDialogTitle("Select White-Space Separated File for Import");

        returnVal = chooser.showOpenDialog(main_frame);

        if (returnVal != JFileChooser.APPROVE_OPTION) {
            return;
        }

        br = null;

        try {
            br = new BufferedReader(new FileReader(chooser.getSelectedFile()));

            while ((inStr = br.readLine()) != null) {
                if (inStr.length() == 0) {
                    continue;
                }

                fromFile.add(new String(inStr));

            }

        } catch (IOException iox) {
            System.err.println("Error reading from file. Error=" + iox.getMessage());

            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException ox) {

                System.err.println("Error closing file. Error=" + ox.getMessage());

            }

            return;
        }

        if (!append) {
            num_rows = table.getRowCount();

            for (row = num_rows - 1; row >= 0; row--) {
                dtm.removeRow(row);
            }

        }

        fromRow = table.getRowCount();

        for (row = 0; row < fromFile.size(); row++) {
            //flds = ((String)fromFile.get(row)).split(pattern);
            flds = ((String) fromFile.get(row)).split("\\s+");

            dtm.addRow(flds);
        }

        haveEdits = true;

        return;

    }		// fromFile

    // inner class for stdout callback handler
    public static class PrintCallbackHandler implements CallbackHandler {

        public void handle(Callback[] callbacks) {
            for (Callback cb : callbacks) {
                // force the callback to TextOutputCallback
                System.out.println("blockette: " + ((TextOutputCallback) cb).getMessage());
            }
        }
    }

    public static PrintCallbackHandler getCallbackHandler() {
        if (printHandler == null) {
            printHandler = new PrintCallbackHandler();
        }
        return printHandler;
    }

    public static void main(String[] args) {
        System.out.println("Doric - v" + version);
        System.out.println("Test regimen -- launching tool...");
        try {
            String blkDefault = PdccDefaultGenerator.getDefaults(53);
            System.out.println("Try, blockette 53, complex zeroes: " + blkDefault);
            Blockette blk53 = BlocketteFactory.createBlockette(blkDefault);
            CallbackHandler hnd = DoricImportTool.getCallbackHandler();
            DoricImportTool dtool = new DoricImportTool(blk53, 10, 13, hnd);  // launch tool for complex zeros in blk 53
        } catch (Exception e) {
            System.err.println("ERROR: exception encountered: " + e);
            e.printStackTrace();
        }
    }
    int width = 800; //600;
    int height = 600; //500;
    Blockette blk;  // this is the blockette that will be edited
    JFrame main_frame;
    JPanel main_panel;
    JTable table;
    JScrollPane sp;
    Toolkit tk;
    boolean haveEdits;
    int startField;
    public static final String version = "1.0";
    CallbackHandler blocketteHandler = null;
    private static PrintCallbackHandler printHandler = null;
}


package edu.iris.pdcc.exception;

import javax.swing.*;
/**
 *  A type of exception specific to problems encountered with
 *  database activity in PDCC
 *
 *  @author Robert Casey
 *  @version 3/5/2004
 */
public class PdccException extends Exception {

	public PdccException() {
		super();
		exStr = "";
	}
	
	public PdccException(String s) {
		super(s);
		exStr = s;
	}
	
	public void showPopup() {
		// pop up a dialogue window
		JOptionPane.showMessageDialog(null,exStr,
				"Exception Warning", JOptionPane.ERROR_MESSAGE);
	}
	
	private String exStr = null;
}



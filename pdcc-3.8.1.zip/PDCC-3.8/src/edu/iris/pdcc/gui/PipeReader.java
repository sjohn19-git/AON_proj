package edu.iris.pdcc.gui;

import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;
import javax.swing.*;

/**
 * Provides stderr/stdout popup display.
 * 
 * @author Chris Laughbon, IRIS DMC<br>
 * modified by Robert Casey, IRIS DMC
 * @version 6/20/2009
 */

//See main() for usage. 

public class PipeReader {
    
    /**
     * Get new instance of PipeReader with indicated parent frame and label.  Creates a popup dialog showing
     * stderr/stdout output messages.
     * If rows is set to 1, then this will be a JTextArea of 1 row for placing in a GUI instead.
     * @param parent parent JFrame to base the popup dialog from
     * @param label title to display at the top of the popup dialog
     */
    public PipeReader(JFrame parent, String label, int rows) {

        if (rows == 1) {
            popup = null;
        } else {
            popup = new JDialog(parent, label, false);
        }
        JButton okBtn;
        Container popupContentPane = null;
        GridBagConstraints c;
        c = new GridBagConstraints();
        if (popup != null) popupContentPane = popup.getContentPane();
        JPanel configPanel = new JPanel();
        configPanel.setLayout(new GridBagLayout());

        
        text = new JTextArea();
        text.setFont(new Font("Dialog", 1, 10));
        text.setRows(rows);
        text.setColumns(80);
        
        okBtn = new JButton("Ok");
        
        c.gridy = 0;
        c.gridx = 0;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridwidth = 5;
        c.gridheight = 5;
        //c.ipadx = 5;
        //c.insets = new Insets(5,10,5,10);
        configPanel.add(new JScrollPane(text), c);
        
        c.gridwidth = 1;
        c.gridheight = 1;
        c.gridy = 6;
        c.gridx = 1;
        configPanel.add(okBtn, c);
        
        okBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                text.setText(null);
                setVisible(false);
            }	
        });
        
        if (popup != null) {
            popupContentPane.add(new JScrollPane(configPanel));

        
            popup.addWindowListener(new WindowAdapter() {
                //public void windowClosed(WindowEvent we) {
                public void windowClosing(WindowEvent we) {
                    text.setText(null);
                    popup.setVisible(false);
                }
            });

            popup.pack();
        }
        
        // -------------------------------
        
        pis = new PipedInputStream();
        
        try {
            pos = new PipedOutputStream(pis);
        } catch (IOException iox) {
            System.out.println("Exiting - I/O error=" + iox.getMessage());
            System.exit(-1);
        }
        
        reader = new Reader();
        
    }

    // create an instance that accepts a JTextField for placing the output into
    public PipeReader(JTextField jt) {

        textField = jt;
        pis = new PipedInputStream();
        try {
            pos = new PipedOutputStream(pis);
        } catch (IOException iox) {
            System.out.println("Exiting - I/O error=" + iox.getMessage());
            System.exit(-1);
        }
        reader = new Reader();
    }

    /**
     * Get the JTextArea widget -- necessary for non popup instances
     */
    public JTextArea getTextArea() {
        return text;
    }


    public String getLastText() {
        return lastText;
    }

    
    /**
     * Trigger visibility of the popup dialog.
     * @param isVisible true to trigger visibility
     */
    public void setVisible(boolean isVisible) {
        if (popup != null) {
            popup.setVisible(isVisible);
            if (isVisible) {
                popup.update(popup.getGraphics());
            }
        }
    }
    
    /**
     * @return true if the popup is current set to visible
     */
    public boolean isShowing() {
        if (popup == null) return false;
        return popup.isShowing();
    }
    
    /**
     * Set whether to listen to STDERR streams or STDOUT streams.
     * @param which integer constant for STDOUT or STDERR
     */
    public void setOut(int which) {
        switch (which) {
        case STDOUT: System.setOut(new PrintStream(pos));
        return;
        case STDERR: System.setErr(new PrintStream(pos));
        return;
        }
    }
    
    /**
     * Starts thread to intercept output stream.
     *
     */
    public void start() {
        reader.start();
    }
    
    /**
     * Stops thread from intercepting output stream.
     *
     */
    public void stop() {
        flagStop = true;
    }
    
    
    private class Reader extends Thread {
        BufferedReader br;
        
        public Reader() {
            br = new BufferedReader(new InputStreamReader(pis));
        }
        
        public void run() {
            Vector in = new Vector();
            int i;
            String s;
            boolean setVisible = false;
            try {
                while (! flagStop) {  // run until signalled to stop
                    in.clear();
                    // REC - changed blocking operation here
//                    s = new String(br.readLine());
//                    in.add(s);
                    while (! br.ready()) sleep(1000);   // block here until data comes in
                    while (br.ready()) {
                        s = new String(br.readLine());
                        in.add(s);
                    }
                    String nextLine = null;
                    for (i = 0; i < in.size(); i++) {
                        nextLine = (String) in.get(i);
                        // filter undesirable messages here
                        if (nextLine.indexOf("log4j:WARN") >= 0) continue;  // skip log4j warning messages
                        if (nextLine.indexOf("edu.iris.nrl.NrlTool getBlocketteStringOutput") >= 0) continue;  // skip NRL tool messages
                        if (nextLine.indexOf("INFO: Datalogger") >= 0) continue;  // skip NRL tool messages
                        if (nextLine.indexOf("INFO: Sensor") >= 0) continue;  // skip NRL tool messages
                        if (nextLine.indexOf("forcing default time value") >= 0) continue;  // skip message that tends to come via RESP
                        if (nextLine.matches("blktype.*No Ending Time")) continue;  // skip message that tends to come via RESP
                        if (blockDebug &&
                            nextLine.indexOf("DEBUG: ") >= 0) continue;  // optionally block DEBUG: messages
                        // append message to window display
                        setVisible = true;
                        if (text != null) {
                            text.append(nextLine);
                            text.append("\n");
                        } else if (textField != null) {
                            textField.setText(nextLine);
                        }
                    }
                    if (text != null) {
                        lastText = nextLine;
                        if (! isShowing()) setVisible(setVisible);
                        // scroll viewport to the end of the text
                        text.setCaretPosition(text.getDocument().getLength());
                    }
                    sleep(1000);
                }
                br.close();   // close buffered reader
                pis.close();  // close input stream
                pos.close();  // close output stream
            } catch (InterruptedException ie) {
                // do nothing if the sleep() method is interrupted.  Continue loop.
            } catch (IOException iox) {
                //System.err.println("IO Error in PipeReader thread");
                //iox.printStackTrace();
                //
                // for IO errors, let's just exit
                return;
            }
        }
    }
    
    /**
     * Default invocation method, launching the dialog to intercept STDERR messages.
     * @param args not used
     */
    public static void main(String [] args) {
        int i = 0;
        PipeReader p = new PipeReader(null, "Error Messages", 20);
        p.setOut(PipeReader.STDERR);
        p.start();
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException ix) {
//            System.out.println("Interrupted");
//        }
//        for (int ii = 0; ii < 10; ii++) {
//            for (i = 0; i < 100; i++) {
//                System.err.println("ERROR " + i);
//            }
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException ix) {
//                System.out.println("Interrupted");
//            }
//        }
    }

    //  creates an instance with a JText Field for STDOUT (not STDERR)
    public static PipeReader createTextLineInstance(JTextField jt) {
        PipeReader p = new PipeReader(jt);
        p.setOut(PipeReader.STDOUT);
        p.start();
        return p;
    }
    
    // instance variables

    // SET THIS TO true TO BLOCK 'DEBUG:' messages
    boolean blockDebug = false;
    
    PipedInputStream pis;
    PipedOutputStream pos;
    Reader reader;
    JTextArea text = null;
    JTextField textField = null;
    JDialog popup;
    //final int scrnWidth = 600;
    //final int scrnHeight = 500;
    static final public int STDERR = 1;
    static final public int STDOUT = 2;
    private boolean flagStop = false;  // trigger to true to stop thread
    private String lastText;
}


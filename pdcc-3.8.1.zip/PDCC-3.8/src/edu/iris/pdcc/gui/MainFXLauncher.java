package edu.iris.pdcc.gui;

import net.java.javafx.FXShell;
import java.util.Locale;
//import javax.swing.UIManager;

public class MainFXLauncher  {
    public static void main(String[] args) {
        try {
//            //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//            //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
//            // if this is a mac, then apply special settings
//            String OSName = System.getProperty("os.name").toLowerCase();
//            System.out.println("DEBUG: OSName = " + OSName);
//            boolean MAC_OS_X = OSName.startsWith("mac os x");
//            if (MAC_OS_X) {
//                System.out.println("DEBUG: set properties for mac");
//                System.out.println("LAF name = " + UIManager.getLookAndFeel());
//                System.setProperty("apple.laf.useScreenMenuBar", "false");  // move menu bar to frame
//                System.setProperty("apple.awt.fileDialogForDirectories", "true"); // allow dir selection in file dialog
//            }

        	// try to set the Locale to US
        	try {
        		Locale.setDefault(Locale.US);
        	} catch (SecurityException se) {
        		System.err.println("Attempted Locale setting to US: Failed...continuing...");
        	}


            // launch JavaFX for PDCC
            FXShell.main(new String[] {"edu.iris.pdcc.gui.PdccFrame"});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
